document.addEventListener("DOMContentLoaded", () => {
  // Ao recarregar a página, o formulário volta ao padrão.
  // A navegação normal entre Builder <-> Templates mantém os dados apenas durante essa troca.
  const navEntry = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
  const isReload = navEntry ? navEntry.type === 'reload' : performance.navigation && performance.navigation.type === 1;
  if (isReload) {
    sessionStorage.removeItem("cvstudioState");
    sessionStorage.removeItem("cvstudioFields");
    sessionStorage.removeItem("cvstudioTemplate");
    localStorage.removeItem("cvstudioState");
    localStorage.removeItem("cvstudioFields");
  }
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const esc = (v="") => String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');

  const state = {
    experiences: [],
    educations: [],
    skills: [],
    languages: [],
    projects: [],
    selectedTemplate: sessionStorage.getItem("cvstudioTemplate") || localStorage.getItem("cvstudioTemplate") || "default"
  };

  const savedState = JSON.parse(sessionStorage.getItem("cvstudioState") || localStorage.getItem("cvstudioState") || "null");
  if (savedState) {
    Object.assign(state, savedState);
    state.selectedTemplate = localStorage.getItem("cvstudioTemplate") || savedState.selectedTemplate || state.selectedTemplate;
  }

  // Remove somente os dados de exemplo antigos. Dados digitados pelo usuário permanecem salvos.
  const isDemoExperience = (x) => x && (
    x.role === "Desenvolvedor Frontend Pleno" ||
    x.role === "Desenvolvedor Frontend Júnior" ||
    x.company === "Empresa ABC" ||
    x.company === "Empresa XYZ"
  );
  const isDemoEducation = (x) => x && x.course === "Ciência da Computação" && x.school === "Universidade";
  const isDemoProject = (x) => x && x.title === "Portfólio Pessoal";
  const demoSkillNames = ["JavaScript","TypeScript","React","Next.js","Tailwind CSS","Node.js"];
  const demoLanguageNames = ["Português","Inglês"];
  state.experiences = (state.experiences || []).filter(x => !isDemoExperience(x));
  state.educations = (state.educations || []).filter(x => !isDemoEducation(x));
  state.projects = (state.projects || []).filter(x => !isDemoProject(x));
  state.skills = (state.skills || []).filter(x => !demoSkillNames.includes(x.name));
  state.languages = (state.languages || []).filter(x => !demoLanguageNames.includes(x.name));
  const saveState = () => sessionStorage.setItem("cvstudioState", JSON.stringify(state));
  saveState();
  const defaultPersonal = {
    cvName: 'Rafael Oliveira',
    cvRole: 'Desenvolvedor Frontend',
    cvEmail: 'seuemail@gmail.com',
    cvPhone: '(11) 0000-0000',
    cvLocation: 'São Paulo, SP',
    cvLinkedin: 'linkedin.com/in/rafaeloliveira',
    cvWebsite: 'rafael.dev',
    cvAbout: ''
  };

  const getSavedFields = () => {
    const saved = JSON.parse(sessionStorage.getItem("cvstudioFields") || localStorage.getItem("cvstudioFields") || "null");
    return saved && typeof saved === 'object' ? {...defaultPersonal, ...saved} : {...defaultPersonal};
  };

  const saveFields = () => {
    const fields = getSavedFields();
    $$('[data-target]').forEach(input => {
      fields[input.dataset.target] = input.value;
    });
    if(fields.cvAbout === 'Desenvolvedor Frontend apaixonado por criar experiências digitais incríveis.') fields.cvAbout = '';
    sessionStorage.setItem("cvstudioFields", JSON.stringify(fields));
    state.personal = fields;
    sessionStorage.setItem("cvstudioState", JSON.stringify(state));
  };

  const loadFields = () => {
    const fields = getSavedFields();
    if(fields.cvAbout === 'Desenvolvedor Frontend apaixonado por criar experiências digitais incríveis.') fields.cvAbout = '';
    $$('[data-target]').forEach(input => {
      if(fields[input.dataset.target] !== undefined) input.value = fields[input.dataset.target];
    });
    sessionStorage.setItem("cvstudioFields", JSON.stringify(fields));
    state.personal = fields;
    sessionStorage.setItem("cvstudioState", JSON.stringify(state));
  };

  const months = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
  const templates = [
    ["default", "Minimal Clean"], ["green", "Minimal Verde"], ["corporate", "Corporate"], ["blue", "Corporate Blue"],
    ["modern", "Modern Blue"], ["dark", "Modern Dark"], ["creative", "Creative"], ["canvas", "Canvas Style"],
    ["executive", "Executive"], ["gold", "Premium Gold"]
  ];
  const monthSelect = (value, attrs) => `<select ${attrs}><option value="">Mês</option>${months.map(m => `<option value="${m}" ${value===m?'selected':''}>${m}</option>`).join('')}</select>`;
  const yearSelect = (value, attrs, includePresent=false) => {
    let html = '<option value="">Ano</option>' + (includePresent ? '<option value="Presente" '+(value==='Presente'?'selected':'')+'>Presente</option>' : '');
    for (let y=1900; y<=3000; y++) html += `<option value="${y}" ${String(value)===String(y)?'selected':''}>${y}</option>`;
    return `<select ${attrs}>${html}</select>`;
  };
  const statusSelect = (value, attrs) => `<select ${attrs}><option ${value==='Concluído'?'selected':''}>Concluído</option><option ${value==='Cursando'?'selected':''}>Cursando</option><option ${value==='Incompleto'?'selected':''}>Incompleto</option></select>`;

  function periodText(item, academic=false){
    const start = [item.startMonth, item.startYear].filter(Boolean).join('/');
    let end = '';
    if (!academic && item.current) end = 'Presente';
    else if (academic && item.status === 'Concluído') end = [item.endMonth, item.endYear].filter(Boolean).join('/');
    else if (!academic) end = [item.endMonth, item.endYear].filter(Boolean).join('/');
    return [start, end].filter(Boolean).join(' - ');
  }

  function updateSimpleFields(){
    $$('[data-target]').forEach(input => {
      const id = input.dataset.target;
      const value = input.value.trim();
      $$(`#${CSS.escape(id)}`).forEach(field => {
        field.textContent = (id === 'cvName' || id === 'cvRole') ? value.toUpperCase() : value;
        (field.closest('p') || field).classList.toggle('hidden-field', value === '');
      });
    });
    const about = $('#cvAbout');
    const aboutSection = about?.closest('section');
    if (aboutSection) aboutSection.style.display = about.textContent.trim() ? '' : 'none';
    saveFields();
  }

  function balls(level){
    let out='';
    for(let i=1;i<=5;i++) out += i <= Number(level) ? '● ' : '○ ';
    return out.trim();
  }

  function updateExperiencePreview(){
    const preview = $('#experiencePreview'); if(!preview) return;
    preview.innerHTML = state.experiences.map(exp => `
      <div class="preview-item">
        ${exp.role ? `<h5>${esc(exp.role)}</h5>` : ''}
        ${(exp.company || periodText(exp)) ? `<p>${esc(exp.company)}${exp.company && periodText(exp) ? ' · ' : ''}${esc(periodText(exp))}</p>` : ''}
        ${exp.desc ? `<ul><li>${esc(exp.desc)}</li></ul>` : ''}
      </div>`).join('');
    const section = preview.closest('section');
    if(section) section.style.display = state.experiences.length ? '' : 'none';
  }

  function renderExperiences(){
    const editor = $('#experienceEditor'); if(!editor) return;
    editor.innerHTML = state.experiences.map((exp,i) => `
      <div class="dynamic-item">
        <label>Cargo <input value="${esc(exp.role)}" data-exp="${i}" data-key="role"></label>
        <label>Empresa <input value="${esc(exp.company)}" data-exp="${i}" data-key="company"></label>
        <div class="period-title">Admissão:</div>
        <div class="period-grid">${monthSelect(exp.startMonth, `data-exp="${i}" data-key="startMonth"`)}${yearSelect(exp.startYear, `data-exp="${i}" data-key="startYear"`)}</div>
        <label class="check-line"><input type="checkbox" data-exp-current="${i}" ${exp.current?'checked':''}> Emprego atual</label>
        <div class="dismissal-wrap ${exp.current?'hidden-field':''}" style="${exp.current?'display:none;':''}">
          <div class="period-title">Demissão:</div>
          <div class="period-grid end-date">${monthSelect(exp.endMonth, `data-exp="${i}" data-key="endMonth" ${exp.current?'disabled':''}`)}${yearSelect(exp.endYear, `data-exp="${i}" data-key="endYear" ${exp.current?'disabled':''}`)}</div>
        </div>
        <label>Descrição <input value="${esc(exp.desc)}" data-exp="${i}" data-key="desc"></label>
        <button type="button" class="remove-btn" data-remove-exp="${i}">Remover</button>
      </div>`).join('');
    editor.querySelectorAll('[data-exp]').forEach(el => {
      const evt = el.tagName === 'SELECT' ? 'change' : 'input';
      el.addEventListener(evt, e => { state.experiences[+e.target.dataset.exp][e.target.dataset.key] = e.target.value; saveState(); updateExperiencePreview(); });
    });
    editor.querySelectorAll('[data-exp-current]').forEach(box => box.addEventListener('change', e => {
      const exp = state.experiences[+e.target.dataset.expCurrent];
      exp.current = e.target.checked;
      if (exp.current) {
        exp.endMonth = '';
        exp.endYear = '';
      }
      saveState();
      renderExperiences();
      updateExperiencePreview();
    }));
    editor.querySelectorAll('[data-remove-exp]').forEach(btn => btn.addEventListener('click', () => { state.experiences.splice(+btn.dataset.removeExp,1); saveState(); renderExperiences(); }));
    updateExperiencePreview();
  }

  function updateEducationPreview(){
    const preview = $('#educationPreview'); if(!preview) return;
    preview.innerHTML = state.educations.map(edu => `
      <div>
        ${edu.course?`<strong>${esc(edu.course)}</strong>`:''}
        ${edu.school?`<span>${esc(edu.school)}</span>`:''}
        ${periodText(edu,true)?`<span>${esc(periodText(edu,true))}</span>`:''}
        ${edu.status?`<span>${esc(edu.status)}</span>`:''}
      </div>`).join('');
    const block = $('#educationBlock') || preview.closest('.live-block');
    if(block) block.style.display = state.educations.length ? '' : 'none';
  }

  function renderEducation(){
    const editor = $('#educationEditor'); if(!editor) return;
    editor.innerHTML = state.educations.map((edu,i) => `
      <div class="dynamic-item">
        <label>Curso <input value="${esc(edu.course)}" data-edu="${i}" data-key="course"></label>
        <label>Instituição <input value="${esc(edu.school)}" data-edu="${i}" data-key="school"></label>
        <label>Status ${statusSelect(edu.status, `data-edu="${i}" data-key="status"`)}</label>
        <div class="period-title">Ingresso:</div>
        <div class="period-grid">${monthSelect(edu.startMonth, `data-edu="${i}" data-key="startMonth"`)}${yearSelect(edu.startYear, `data-edu="${i}" data-key="startYear"`)}</div>
        <div class="completion-wrap ${edu.status==='Concluído'?'':'hidden-field'}">
          <div class="period-title">Conclusão:</div>
          <div class="period-grid end-date">${monthSelect(edu.endMonth, `data-edu="${i}" data-key="endMonth"`)}${yearSelect(edu.endYear, `data-edu="${i}" data-key="endYear"`)}</div>
        </div>
        <button type="button" class="remove-btn" data-remove-edu="${i}">Remover</button>
      </div>`).join('');
    editor.querySelectorAll('[data-edu]').forEach(el => {
      const evt = el.tagName === 'SELECT' ? 'change' : 'input';
      el.addEventListener(evt, e => {
        const edu = state.educations[+e.target.dataset.edu]; edu[e.target.dataset.key] = e.target.value;
        if(e.target.dataset.key === 'status'){
          if(edu.status !== 'Concluído'){ edu.endMonth=''; edu.endYear=''; }
          saveState(); renderEducation(); return;
        }
        saveState(); updateEducationPreview();
      });
    });
    editor.querySelectorAll('[data-remove-edu]').forEach(btn => btn.addEventListener('click', () => { state.educations.splice(+btn.dataset.removeEdu,1); saveState(); renderEducation(); }));
    updateEducationPreview();
  }

  function updateSkillsPreview(){
    const preview = $('#skillsPreview'); if(!preview) return;
    preview.innerHTML = state.skills.map(skill => `<div class="skill-row"><span>${esc(skill.name || 'Habilidade')}</span><b>${balls(skill.level)}</b></div>`).join('');
    const block = $('#skillsBlock') || preview.closest('.live-block');
    if(block) block.style.display = state.skills.length ? '' : 'none';
  }

  function renderSkills(){
    const editor = $('#skillsEditor'); if(!editor) return;
    editor.innerHTML = state.skills.map((skill,i) => `
      <div class="skill-editor-row">
        <label>Habilidade <input value="${esc(skill.name)}" data-skill="${i}" data-key="name"></label>
        <label>Nível <span class="range-value">${skill.level}/5</span><input type="range" min="0" max="5" step="1" value="${skill.level}" data-skill="${i}" data-key="level"></label>
        <button type="button" class="remove-btn" data-remove-skill="${i}">Remover</button>
      </div>`).join('');
    editor.querySelectorAll('[data-skill]').forEach(el => el.addEventListener('input', e => {
      const skill = state.skills[+e.target.dataset.skill];
      skill[e.target.dataset.key] = e.target.dataset.key === 'level' ? +e.target.value : e.target.value;
      const value = e.target.closest('label')?.querySelector('.range-value'); if(value) value.textContent = `${e.target.value}/5`;
      saveState(); updateSkillsPreview();
    }));
    editor.querySelectorAll('[data-remove-skill]').forEach(btn => btn.addEventListener('click', () => { state.skills.splice(+btn.dataset.removeSkill,1); saveState(); renderSkills(); }));
    updateSkillsPreview();
  }

  function updateLanguagesPreview(){
    const preview = $('#languagesPreview'); if(!preview) return;
    preview.innerHTML = state.languages.map(lang => `<div class="skill-row"><span>${esc(lang.name || 'Idioma')}</span><b>${balls(lang.level)}</b></div>`).join('');
    const block = $('#languagesBlock') || preview.closest('.live-block');
    if(block) block.style.display = state.languages.length ? '' : 'none';
  }

  function renderLanguages(){
    const editor = $('#languagesEditor'); if(!editor) return;
    editor.innerHTML = state.languages.map((lang,i) => `
      <div class="skill-editor-row">
        <label>Idioma <input value="${esc(lang.name)}" data-lang="${i}" data-key="name"></label>
        <label>Proficiência <span class="range-value">${lang.level}/5</span><input type="range" min="0" max="5" step="1" value="${lang.level}" data-lang="${i}" data-key="level"></label>
        <button type="button" class="remove-btn" data-remove-lang="${i}">Remover</button>
      </div>`).join('');
    editor.querySelectorAll('[data-lang]').forEach(el => el.addEventListener('input', e => {
      const lang = state.languages[+e.target.dataset.lang];
      lang[e.target.dataset.key] = e.target.dataset.key === 'level' ? +e.target.value : e.target.value;
      const value = e.target.closest('label')?.querySelector('.range-value'); if(value) value.textContent = `${e.target.value}/5`;
      saveState(); updateLanguagesPreview();
    }));
    editor.querySelectorAll('[data-remove-lang]').forEach(btn => btn.addEventListener('click', () => { state.languages.splice(+btn.dataset.removeLang,1); saveState(); renderLanguages(); }));
    updateLanguagesPreview();
  }

  function updateProjectsPreview(){
    const preview = $('#projectsPreview'); if(!preview) return;
    preview.innerHTML = state.projects.map(project => `
      <div class="preview-item">
        ${project.title ? `<h5>${esc(project.title)}</h5>` : ''}
        ${project.desc ? `<p>${esc(project.desc)}</p>` : ''}
      </div>`).join('');
    const section = preview.closest('section');
    if(section) section.style.display = state.projects.length ? '' : 'none';
  }

  function renderProjects(){
    const editor = $('#projectsEditor'); if(!editor) return;
    editor.innerHTML = state.projects.map((project,i) => `
      <div class="dynamic-item">
        <label>Título <input value="${esc(project.title)}" data-project="${i}" data-key="title"></label>
        <label>Descrição <input value="${esc(project.desc)}" data-project="${i}" data-key="desc"></label>
        <button type="button" class="remove-btn" data-remove-project="${i}">Remover</button>
      </div>`).join('');
    editor.querySelectorAll('[data-project]').forEach(el => el.addEventListener('input', e => {
      const project = state.projects[+e.target.dataset.project];
      project[e.target.dataset.key] = e.target.value;
      saveState(); updateProjectsPreview();
    }));
    editor.querySelectorAll('[data-remove-project]').forEach(btn => btn.addEventListener('click', () => { state.projects.splice(+btn.dataset.removeProject,1); saveState(); renderProjects(); }));
    updateProjectsPreview();
  }

  function renderTemplateSelector(){
    const box = $('.template-link-card'); if(!box) return;
    const current = $('#templateCurrent');
    const name = templates.find(t => t[0] === state.selectedTemplate)?.[1] || 'Minimal Clean';
    if(current) current.textContent = `Template atual: ${name}`;
  }

  function applyTemplate(){
    const resume = $('#resumeToExport'); if(!resume) return;
    resume.className = 'live-resume';
    if(state.selectedTemplate !== 'default') resume.classList.add(`template-${state.selectedTemplate}`);
    sessionStorage.setItem("cvstudioTemplate", state.selectedTemplate);
    const name = templates.find(t => t[0] === state.selectedTemplate)?.[1] || state.selectedTemplate;
    const current = $('#templateCurrent'); if(current) current.textContent = `Template atual: ${name}`;
  }

  const persistAll = () => {
    saveFields();
    state.selectedTemplate = sessionStorage.getItem("cvstudioTemplate") || localStorage.getItem("cvstudioTemplate") || state.selectedTemplate || 'default';
    saveState();
    sessionStorage.setItem("cvstudioTemplate", state.selectedTemplate);
  };
  window.addEventListener('beforeunload', persistAll);
  document.addEventListener('click', (e) => {
    if (e.target.closest('a[href="templates.html"], .template-select-btn')) persistAll();
  }, true);
  $$('[data-target]').forEach(input => input.addEventListener('input', () => { updateSimpleFields(); persistAll(); }));
  $$('[data-na]').forEach(box => box.addEventListener('change', () => { const input = box.closest('.na-row')?.querySelector('[data-target]'); if(box.checked && input) input.value=''; updateSimpleFields(); }));
  $('#addExperience')?.addEventListener('click', () => { state.experiences.push({role:'',company:'',startMonth:'',startYear:'',endMonth:'',endYear:'',current:false,desc:''}); saveState(); renderExperiences(); });
  $('#addEducation')?.addEventListener('click', () => { state.educations.push({course:'',school:'',startMonth:'',startYear:'',endMonth:'',endYear:'',status:'Cursando'}); saveState(); renderEducation(); });
  $('#addSkill')?.addEventListener('click', () => { state.skills.push({name:'',level:3}); saveState(); renderSkills(); });
  $('#addLanguage')?.addEventListener('click', () => { state.languages.push({name:'',level:3}); saveState(); renderLanguages(); });
  $('#addProject')?.addEventListener('click', () => { state.projects.push({title:'',desc:''}); saveState(); renderProjects(); });
  $('#darkToggle')?.addEventListener('click', () => document.body.classList.toggle('dark-mode'));
  $('#photoInput')?.addEventListener('change', e => { const file=e.target.files?.[0]; if(!file) return; const reader=new FileReader(); reader.onload=ev=>{ const img=$('#resumePhoto'); if(img) img.src=ev.target.result; }; reader.readAsDataURL(file); });
  $('#exportPdf')?.addEventListener('click', () => { const element=$('#resumeToExport'); if(!element || !window.html2pdf) return; document.body.classList.add('pdf-exporting'); html2pdf().set({margin:0,filename:'curriculo-cvstudio.pdf',image:{type:'jpeg',quality:1},html2canvas:{scale:2,useCORS:true,scrollX:0,scrollY:0},jsPDF:{unit:'pt',format:'a4',orientation:'portrait'}}).from(element).save().finally(()=>document.body.classList.remove('pdf-exporting')); });

  loadFields(); renderExperiences(); renderEducation(); renderSkills(); renderLanguages(); renderProjects(); renderTemplateSelector(); updateSimpleFields(); applyTemplate();
  if(window.lucide) lucide.createIcons();
});
